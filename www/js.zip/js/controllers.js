angular.module('ionic-ecommerce.controllers', [])
.controller('TabCtrl', TabCtrl)
.controller('HomeCtrl', HomeCtrl)
.controller('ProductsCtrl', ProductsCtrl)
.controller('ProductDetailCtrl', ProductDetailCtrl)
.controller('CartCtrl', CartCtrl)
.controller('AccountCtrl', AccountCtrl)
.controller('LoginCtrl', LoginCtrl);

// Tab Controller
TabCtrl.$inject = ['$scope', 'CartService', 'CONFIG'];
function TabCtrl(   $scope,   CartService,   CONFIG) {
  var vm = this;
  vm.count = CartService.getCount();
  vm.messages = CONFIG.tabs;

  $scope.$watch(function(){ return CartService.getCount();}, function(current, original) {
    vm.count = current;
  });
}

// Home Controller
HomeCtrl.$inject = ['ProductService', 'CartService', 'CONFIG', '$scope', '$state', '$ionicPopup', '$ionicSlideBoxDelegate', '$timeout'];
function HomeCtrl(   ProductService,   CartService,   CONFIG,   $scope,   $state,   $ionicPopup,   $ionicSlideBoxDelegate,   $timeout) {
  var vm = this,
      cacheLoaded = false;

  vm.show_featured = false;
  vm.addedToCart = false;
  vm.addToCart = addToCart;
  vm.messages = CONFIG.home;

  $scope.$on('$ionicView.enter', function(e) {
    if (!cacheLoaded) {
      ProductService.all(cacheLoaded)
      .then(function(data){
        cacheLoaded = true;
        vm.show_featured = true;
        vm.featured = data.response.products;
        for (var key in vm.featured) {
          var product = vm.featured[key];
          product.home_image = CONFIG.image_root + product.master.images[0].product_url;
        }
        $ionicSlideBoxDelegate.update();
      },
      function(data) {
        var popup = $ionicPopup.confirm({
          title: 'Error!',
          template: 'Error retrieving products: ' + data.status + '<br>Try Again?',
          cancelText: 'No',
          okText: 'Yes'
        });
        popup.then(function(res){
          if (res) {$state.reload();}
        });
      });
    }
  });

    function addToCart(product, $event) {
      $event.stopPropagation();
      CartService.add(product);
      vm.addedToCart = true;
      $timeout(function(){vm.addedToCart = false;}, 700);
    }
}

//Products Controller
ProductsCtrl.$inject = ['$state', '$ionicLoading', '$ionicPopup', 'AuthService', 'ProductService', 'CONFIG'];
function ProductsCtrl(   $state,   $ionicLoading,   $ionicPopup,   AuthService,   ProductService,   CONFIG) {
    var vm = this;
    vm.messages = CONFIG.products;

    //ketu kaloj tek cart (e view) te gjitha vlerat e marra nga sherbimi

    vm.thedata = ProductService.myDataPromise.then(function(result) {
        vm.productdata = result;
        console.log(result);
    });



    $ionicLoading.show();
    ProductService.all()
        .then(function(data) {
                vm.all = data.response.products;
                for (var key in vm.all) {
                    var product = vm.all[key];
                    product.image = CONFIG.image_root + product.master.images[0].mini_url;
                }
                $ionicLoading.hide();
            },
            function(data) {
                console.log("ProductsCtrl Products.all error: " + data.rejection.error);
                var popup = $ionicPopup.alert({
                    title: 'Error!',
                    template: 'Error retrieving products: ' + data.rejection.error
                });
                popup.then(function(){
                    $ionicLoading.hide();
                    $state.go('home');
                });
            });
}

// Product Detail Controller
ProductDetailCtrl.$inject = ['$stateParams', '$state', '$ionicLoading', '$ionicPopup', '$timeout', 'CONFIG', 'AuthService', 'ProductService', 'CartService', ];
function ProductDetailCtrl(   $stateParams,   $state,   $ionicLoading,   $ionicPopup,   $timeout,   CONFIG,   AuthService,   ProductService,   CartService) {
  var vm = this;
  vm.messages = CONFIG.product;
  vm.addedToCart = false;
  var slug = $stateParams.slug;
  vm.addToCart = addToCart;

  $ionicLoading.show();
  ProductService.get(slug)
  .then(function(data) {
      vm.name = data.response.name;
      vm.price = data.response.price;
      vm.description = data.response.description;
      vm.image = CONFIG.image_root + data.response.master.images[0].product_url;
      vm.product = data.response;
      $ionicLoading.hide();
    },
    function(data) {
      console.log("ProductDetailCtrl Products.get error: " + data.rejection.error);
      var popup = $ionicPopup.alert({
        title: 'Error!',
        template: 'Error retrieving product: ' + data.rejection.error
      });
      popup.then(function() {
        $ionicLoading.hide();
        $state.go('products');
      });
    });

  function addToCart(product) {
    CartService.add(product);
    vm.addedToCart = true;
    $timeout(function(){vm.addedToCart = false;}, 700);
  }
}

// Cart Controller
CartCtrl.$inject = ['$scope', '$state', 'CartService', 'CONFIG'];
function CartCtrl(   $scope,   $state,   CartService,   CONFIG) {
  var vm = this;
  vm.messages = CONFIG.cart;
  vm.remove = remove;

  $scope.$on('$ionicView.enter', function(e) {
    vm.products = CartService.products;
    vm.total = CartService.total;
    for (var key in vm.products) {
      var product = vm.products[key];
      product.image = CONFIG.image_root + product.master.images[0].mini_url;
    }
  });

  function remove(product) {
    CartService.remove(product);
    vm.total = CartService.total;
    $state.reload();
  }

}


AccountCtrl.$inject = ['$scope', '$state', '$stateParams', 'AuthService', 'LocalStorage', 'CONFIG'];
function AccountCtrl(   $scope,   $state, $stateParams,  AuthService, LocalStorage,   CONFIG) {
    var vm = this;
    vm.messages = CONFIG.account;
    vm.logout = logout;
    vm.loginresponse = {};
    vm.credentials = {};
    vm.thisuser = {};

    vm.userisloggedin = LocalStorage.get('isloggedin');
    if(LocalStorage.get('currentstate')) {vm.currentstate = LocalStorage.get('currentstate');}
    else {vm.currentstate = 'ataccountmain';}

    vm.thisuser.username = (LocalStorage.get('username')) ? LocalStorage.get('username') : '';
    vm.thisuser.email = (LocalStorage.get('email')) ? LocalStorage.get('email') : '';
    vm.thisuser.gender = (LocalStorage.get('gender')) ? LocalStorage.get('gender') : '';
    vm.thisuser.phone = (LocalStorage.get('phone')) ? LocalStorage.get('phone') : '';
    vm.thisuser.country = (LocalStorage.get('country')) ? LocalStorage.get('country') : '';
    vm.thisuser.city = (LocalStorage.get('city')) ? LocalStorage.get('city') : '';
    vm.thisuser.street = (LocalStorage.get('street')) ? LocalStorage.get('street') : '';
    vm.thisuser.password = (LocalStorage.get('password')) ? LocalStorage.get('password') : '';
    vm.thisuser.language = (LocalStorage.get('language')) ? LocalStorage.get('language') : '';

    $scope.$on('$ionicView.enter', function(e) {
        vm.logged_in = AuthService.isAuthenticated();
        vm.token = AuthService.token();
    });

    //set language
    if(LocalStorage.get('language')) vm.language = LocalStorage.get('language');
    else vm.language = 'en';
    //change language
    $scope.savelang = function (language) {
        LocalStorage.set('language', language);
        $state.go('account_info');
    }

    //appoint result returned from login
    $scope.log_in = function (username, password) {
        var promise = AuthService.loginuser(username, password);
        LocalStorage.set('username', password);
        promise.then(function(response){
            if(response.data.id){
                //store data in local storage
                LocalStorage.set('username', response.data.name);
                LocalStorage.set('email', response.data.email);
                LocalStorage.set('gender', response.data.gender);
                LocalStorage.set('country', response.data.country);
                LocalStorage.set('city', response.data.city);
                LocalStorage.set('street', response.data.street);
                LocalStorage.set('phone', response.data.phone);

                $state.go('account_info', {
                    username: response.data.name,
                    email: response.data.email,
                    country: response.data.country,
                    city: response.data.city,
                    street: response.data.street,
                    phone: response.data.phone
                });
            }
            else{
                //show modal
                console.log("te else");
                    var alertPopup = $ionicPopup.alert({
                        title: 'Incorrect credentials',
                        template: 'Username and password do not match'
                    });

                    alertPopup.then(function(res) {
                        console.log(response.data);
                    });
            }
        });
    }

    //appoint result returned from login
    $scope.createuser = function (username, password, email) {
        console.log(username+' --- '+password+' --- '+email);
        var promise = AuthService.create_new_user(username, password, email);
        promise.then(function(response){
            vm.loginresponse = response.data; //pass user info to view
            $state.go('account_info');
        });
    }

    //edit user info
 /*   $scope.updateuser = function (gender) {
        console.log(' --- gender---- '+gender+' --- ');
        var promise = AuthService.update_user (gender);
        promise.then(function(response){
            vm.loginresponse = response.data; //pass user info to view
            $state.go('account_info');
        });
    }
*/
    $scope.updateuser = function (gender) {
        LocalStorage.set('gender', gender);
        console.log(gender+"gender")
        $state.go('account_info');
    }

    $scope.log_out = function () {
        LocalStorage.set("isloggedin", false);
        console.log("local storage isloggein te logout "+LocalStorage.get("isloggedin"));
        $state.go('account');
        console.log(vm.credentials.username+' --- '+vm.credentials.password);
    }



    $scope.gotologin = function (){
        console.log("@gotologin");
        $state.go('account_login');
    }

    $scope.gotoregister = function(){
        console.log("@gotoregister");
        $state.go('account_create');
    }

    $scope.gotomain = function () {
        console.log("@gotomain");
        $state.go('account');
    }

    $scope.editaccount = function () {
        console.log("@editaccount");
        $state.go('account_edit');
    }

    $scope.gotoaccountinfo = function () {
        console.log("@going acount info");
        $state.go('account_info');
    }

    $scope.showsettings = function () {
        console.log("@showsettings");
        $state.go('account_settings');
    }

    function logout() {
        AuthService.logout();
        vm.user = null;
        vm.token = null;
        vm.logged_in = AuthService.isAuthenticated();
        $state.reload('account');
    }
}

// Login Controller
LoginCtrl.$inject = ['$state', '$ionicLoading', '$ionicPopup', 'AuthService', 'CONFIG'];
function LoginCtrl(   $state,   $ionicLoading,   $ionicPopup,   AuthService,   CONFIG) {
  var vm = this;
  vm.messages = CONFIG.login;
  vm.go = go;

  function go(user) {
    $ionicLoading.show();
    vm.user = null;
    AuthService.login(user.email, user.password)
      .success(function(data) {
        console.log("successful login; token: " + data.token);
        $state.go('account', {}, {reload: true});
        $ionicLoading.hide();
      })
      .error(function(data) {
        console.log("login failed", data.error);
        $ionicLoading.hide();
        var alertPopup = $ionicPopup.alert({
          title: 'Login failed!',
          template: data.error
        });
      });
  }
}

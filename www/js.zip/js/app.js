angular.module('ionic-ecommerce', ['ionic', 'ionic-ecommerce.controllers', 'ionic-ecommerce.services'])
.run(Runner)
.config(Configurator);

Runner.$inject = ['$ionicPlatform', '$rootScope'];
function Runner($ionicPlatform, $rootScope) {
  $rootScope.$on("$stateChangeError", console.log.bind(console));
  $ionicPlatform.ready(function() {
    // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
    // for form inputs)
    if (window.cordova && window.cordova.plugins && window.cordova.plugins.Keyboard) {
      cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
    }
    if (window.StatusBar) {
      // org.apache.cordova.statusbar required
      StatusBar.styleLightContent();
    }
  });
}

Configurator.$inject = ['$httpProvider', '$stateProvider', '$urlRouterProvider'];
function Configurator($httpProvider, $stateProvider, $urlRouterProvider) {

  $httpProvider.defaults.withCredentials = true;
  $httpProvider.defaults.headers.common["X-CSRF-Token"] = $("meta[name=csrf-token]").attr("content");

  $urlRouterProvider.otherwise('/');

  $stateProvider

  .state('app', {
    url: '',
    abstract: true,
    templateUrl: 'templates/tabs.html',
    controller: 'TabCtrl as tabs'
  })

  .state('home', {
    url: '/',
    parent: 'app',
    views: {
      'home': {
        templateUrl: 'templates/home.html',
        controller: 'HomeCtrl as home'
      }
    }
  })

  .state('products', {
    url: '/products',
    parent: 'app',
    views: {
      'products-tab@app': {
        templateUrl: 'templates/products.html',
        controller: 'ProductsCtrl as products'
      }
    }
  })

  .state('products-detail', {
    url: '/products/:slug',
    parent: 'app',
    views: {
      'products-tab@app': {
        templateUrl: 'templates/products.detail.html',
        controller: 'ProductDetailCtrl as product'
      }
    }
  })

  .state('cart', {
    url: '/cart',
    parent: 'app',
    views: {
      'cart': {
        templateUrl: 'templates/cart.html',
        controller: 'CartCtrl as cart'
      }
    }
  })

  .state('account', {
    url: '/account',
    parent: 'app',
    views: {
      'account': {
        templateUrl: 'templates/account.html',
        controller: 'AccountCtrl as account'
      }
    }
  })
      .state('account_login', {
          url: '/accounts/login',
          parent: 'app',
          views: {
              'account': {
                  templateUrl: 'templates/account.logins.html',
                  controller: 'AccountCtrl as account'
              }
          }
      })
      .state('account_create', {
          url: '/account/create',
          parent: 'app',
          views: {
              'account': {
                  templateUrl: 'templates/account.signup.html',
                  controller: 'AccountCtrl as account'
              }
          }
      })
      .state('account_info', {
          url: '/account/info',
          params : { username: null, email: null, ountry: null, city: null, phone: null },
          parent: 'app',
          views: {
              'account': {
                  templateUrl: 'templates/account.info.html',
                  controller: 'AccountCtrl as account'
              }
          }
      })
      .state('account_edit', {
          url: '/account/edit',
          parent: 'app',
          views: {
              'account': {
                  templateUrl: 'templates/account.edit.html',
                  controller: 'AccountCtrl as account'
              }
          }
      })
      .state('account_settings', {
          url: '/account/settings',
          parent: 'app',
          views: {
              'account': {
                  templateUrl: 'templates/account.settings.html',
                  controller: 'AccountCtrl as account'
              }
          }
      })
  .state('login', {
    url: '/account/login',
    parent: 'app',
    views: {
      'account': {
        templateUrl: 'templates/account.login.html',
        controller: 'LoginCtrl as login'
      }
    }
  });
}
